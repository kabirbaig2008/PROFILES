chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(
    ["enabled", "cursorCount", "cursorColor", "cursorSize"],
    (settings) => {
      chrome.storage.sync.set({
        enabled: settings.enabled ?? true,
        cursorCount: settings.cursorCount ?? 8,
        cursorColor: settings.cursorColor ?? "#7c3aed",
        cursorSize: settings.cursorSize ?? 18
      });
    }
  );
});