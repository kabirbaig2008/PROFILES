(() => {
  if (window.__swarmCursorsInitialized) return;
  window.__swarmCursorsInitialized = true;

  let cursors = [];
  let animationFrame = null;
  let mouseX = window.innerWidth / 2;
  let mouseY = window.innerHeight / 2;

  let settings = {
    enabled: true,
    cursorCount: 8,
    cursorColor: "#7c3aed",
    cursorSize: 18
  };

  function removeSwarm() {
    if (animationFrame !== null) {
      cancelAnimationFrame(animationFrame);
      animationFrame = null;
    }

    cursors.forEach(cursor => cursor.destroy());
    cursors = [];
  }

  function createSwarm() {
    removeSwarm();
    if (!settings.enabled) return;

    const count = Math.max(1, Math.min(30, Number(settings.cursorCount) || 8));
    for (let i = 0; i < count; i++) {
      cursors.push(
        new SwarmCursor(
          settings.cursorColor || "#7c3aed",
          Math.max(6, Math.min(40, Number(settings.cursorSize) || 18)),
          i
        )
      );
    }

    animate();
  }

  function animate() {
    if (!cursors.length) return;

    cursors.forEach((cursor, index) => {
      const angle = (index / cursors.length) * Math.PI * 2;
      const distance = 25 + index * 5;

      cursor.setTarget(
        mouseX + Math.cos(angle) * distance,
        mouseY + Math.sin(angle) * distance
      );
      cursor.update();
    });

    animationFrame = requestAnimationFrame(animate);
  }

  document.addEventListener("mousemove", event => {
    mouseX = event.clientX;
    mouseY = event.clientY;
  }, { passive: true });

  chrome.storage.sync.get(settings, result => {
    settings = { ...settings, ...result };
    createSwarm();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;

    Object.keys(changes).forEach(key => {
      settings[key] = changes[key].newValue;
    });

    createSwarm();
  });

  window.addEventListener("pagehide", removeSwarm);
})();