const enabled = document.getElementById("enabled");
const cursorCount = document.getElementById("cursorCount");
const cursorColor = document.getElementById("cursorColor");
const cursorSize = document.getElementById("cursorSize");

const countValue = document.getElementById("countValue");
const sizeValue = document.getElementById("sizeValue");

const resetButton = document.getElementById("resetButton");
const status = document.getElementById("status");

const defaults = {
  enabled: true,
  cursorCount: 8,
  cursorColor: "#7c3aed",
  cursorSize: 18
};

function updateStatus(message) {
  status.textContent = message;
}

function saveSettings() {
  const settings = {
    enabled: enabled.checked,
    cursorCount: Number(cursorCount.value),
    cursorColor: cursorColor.value,
    cursorSize: Number(cursorSize.value)
  };

  chrome.storage.sync.set(settings, () => {
    if (chrome.runtime.lastError) {
      updateStatus("Could not save settings");
      return;
    }
    updateStatus("Settings saved!");
  });
}

function loadSettings() {
  chrome.storage.sync.get(defaults, settings => {
    enabled.checked = settings.enabled;
    cursorCount.value = settings.cursorCount;
    cursorColor.value = settings.cursorColor;
    cursorSize.value = settings.cursorSize;
    countValue.textContent = settings.cursorCount;
    sizeValue.textContent = settings.cursorSize;
  });
}

enabled.addEventListener("change", saveSettings);

cursorCount.addEventListener("input", () => {
  countValue.textContent = cursorCount.value;
  saveSettings();
});

cursorColor.addEventListener("input", saveSettings);

cursorSize.addEventListener("input", () => {
  sizeValue.textContent = cursorSize.value;
  saveSettings();
});

resetButton.addEventListener("click", () => {
  chrome.storage.sync.set(defaults, () => {
    if (chrome.runtime.lastError) {
      updateStatus("Could not reset settings");
      return;
    }
    loadSettings();
    updateStatus("Settings reset!");
  });
});

loadSettings();