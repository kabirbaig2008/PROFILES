class SwarmCursor {
  constructor(color, size, index) {
    this.x = window.innerWidth / 2;
    this.y = window.innerHeight / 2;
    this.targetX = this.x;
    this.targetY = this.y;
    this.index = index;

    this.element = document.createElement("div");
    this.element.className = "swarm-cursor";
    this.element.style.width = `${size}px`;
    this.element.style.height = `${size}px`;
    this.element.style.backgroundColor = color;
    this.element.style.boxShadow = `0 0 15px ${color}`;

    document.documentElement.appendChild(this.element);
  }

  setTarget(x, y) {
    this.targetX = x;
    this.targetY = y;
  }

  update() {
    animateCursor(this, this.targetX, this.targetY);
  }

  destroy() {
    this.element.remove();
  }
}