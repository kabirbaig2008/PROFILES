function lerp(start, end, amount) {
  return start + (end - start) * amount;
}

function randomBetween(min, max) {
  return Math.random() * (max - min) + min;
}

function animateCursor(cursor, targetX, targetY) {
  cursor.x = lerp(cursor.x, targetX, 0.12);
  cursor.y = lerp(cursor.y, targetY, 0.12);

  cursor.element.style.transform =
    `translate3d(${cursor.x}px, ${cursor.y}px, 0)`;
}

function createRandomTarget() {
  return {
    x: randomBetween(20, window.innerWidth - 20),
    y: randomBetween(20, window.innerHeight - 20)
  };
}